'use client';

import React from 'react';
import Link from 'next/link';
import { trackCTAClick, trackBookConsultationClick } from '@/lib/analytics';

export default function ServicesWorkCTA() {
  return (
    <section className="py-16 md:py-24 bg-secondary/40 border-t border-border">
      <div className="max-w-4xl mx-auto px-5 md:px-10 text-center">
        <p className="text-xs font-semibold uppercase tracking-[0.35em] text-accent mb-4 md:mb-5 flex items-center justify-center gap-3">
          <span className="w-6 h-px bg-accent" />
          Available Nationwide
          <span className="w-6 h-px bg-accent" />
        </p>
        <h2 className="text-section-heading text-foreground mb-5 md:mb-6">
          Ready to strengthen
          <br />
          <span className="italic opacity-80">your practice?</span>
        </h2>
        <p className="text-muted-foreground text-base md:text-lg font-light leading-relaxed max-w-lg mx-auto mb-8 md:mb-10">
          Whether you need ongoing legal support or project-based assistance,
          I'm available to discuss how I can serve your firm's unique needs.
        </p>
        <div className="flex flex-col sm:flex-row flex-wrap items-stretch sm:items-center justify-center gap-3 sm:gap-4">
          <Link
            href="/book-consultation"
            onClick={() => {
              trackCTAClick('Schedule a Consultation', 'services_cta', '/book-consultation');
              trackBookConsultationClick('services_cta');
            }}
            className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-primary text-primary-foreground rounded-full text-sm font-semibold uppercase tracking-widest hover:opacity-90 transition-all duration-300 hover:gap-3"
          >
            Schedule a Consultation
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </Link>
          <a
            href="mailto:broussardlegalservices@gmail.com"
            onClick={() => trackCTAClick('Email Direct', 'services_cta', 'mailto:broussardlegalservices@gmail.com')}
            className="inline-flex items-center justify-center gap-2 px-8 py-4 border border-border text-foreground rounded-full text-sm font-medium tracking-wide hover:border-accent hover:text-accent transition-all duration-300"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
              <rect width="20" height="16" x="2" y="4" rx="2" /><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
            </svg>
            Send an Email
          </a>
        </div>
      </div>
    </section>
  );
}